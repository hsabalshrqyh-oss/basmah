<?php
/**
 * صفحة هبوط مكتب ابو بسام - WordPress Theme
 * لتفعيل: المظهر ← الثيمات ← رفع ثيم
 */
?><!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>مكتب ابو بسام</title>
  <?php wp_head(); ?>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet" />
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Cairo', sans-serif;
      background: #f0f4fa;
      color: #1a2a4a;
      direction: rtl;
    }

    /* ====== FLOATING ICONS ====== */
    .floating-icons {
      position: fixed;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      z-index: 999;
      display: flex;
      flex-direction: column;
      gap: 18px;
      align-items: center;
    }

    .float-btn {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 54px;
      height: 54px;
      border-radius: 50%;
      text-decoration: none;
      animation: floatIcon 3s ease-in-out infinite;
    }

    .float-btn.wa  { background: linear-gradient(135deg, #25d366, #128c50); box-shadow: 0 4px 20px rgba(37,211,102,.45); }
    .float-btn.tel { background: linear-gradient(135deg, #3b82f6, #1d4ed8); box-shadow: 0 4px 20px rgba(59,130,246,.45); animation-delay: 1s; }

    .float-btn::before,
    .float-btn::after {
      content: '';
      position: absolute;
      border-radius: 50%;
      animation: pulseRing 2s ease-out infinite;
    }
    .float-btn::before { inset: -8px; }
    .float-btn::after  { inset: -16px; animation-delay: .4s; }

    .float-btn.wa::before,
    .float-btn.wa::after  { background: rgba(37,211,102,.35); }
    .float-btn.tel::before,
    .float-btn.tel::after { background: rgba(59,130,246,.35); animation-delay: .9s; }

    .float-btn svg { width: 26px; height: 26px; fill: #fff; position: relative; z-index: 1; }

    @keyframes pulseRing {
      0%   { transform: scale(1);   opacity: .7; }
      100% { transform: scale(1.5); opacity: 0; }
    }
    @keyframes floatIcon {
      0%,100% { transform: translateY(0); }
      50%      { transform: translateY(-6px); }
    }

    /* ====== HEADER ====== */
    header {
      background: #0d1b35;
      border-bottom: 1px solid rgba(201,162,39,.25);
      height: 64px;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      padding: 0 24px;
      position: sticky;
      top: 0;
      z-index: 40;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .brand-icon {
      width: 38px; height: 38px;
      border-radius: 10px;
      background: linear-gradient(135deg, #c9a227, #f0c84a);
      display: flex; align-items: center; justify-content: center;
      font-weight: 900; font-size: 18px;
      color: #0d1b35;
    }

    .brand-name {
      font-weight: 700; font-size: 15px;
      color: #f0c84a;
    }

    /* ====== HERO ====== */
    .hero {
      background: linear-gradient(160deg, #0d1b35 0%, #162547 60%, #1e3560 100%);
      padding: 64px 24px 80px;
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .hero::after {
      content: '';
      position: absolute;
      bottom: -2px; left: 0; right: 0;
      height: 44px;
      background: #f0f4fa;
      border-radius: 50% 50% 0 0 / 100% 100% 0 0;
    }

    .gold-bar {
      width: 60px; height: 3px;
      background: linear-gradient(90deg, #c9a227, #f0c84a);
      border-radius: 2px;
      margin: 0 auto 24px;
    }

    .hero h1 {
      font-size: clamp(34px, 7vw, 60px);
      font-weight: 900;
      background: linear-gradient(90deg, #c9a227, #f0c84a, #c9a227);
      background-size: 200%;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      animation: shimmer 3s linear infinite;
      margin-bottom: 14px;
    }

    @keyframes shimmer {
      0%   { background-position: 0% }
      100% { background-position: 200% }
    }

    .hero p {
      font-size: clamp(15px, 2.5vw, 19px);
      color: rgba(230,220,195,.85);
      max-width: 540px;
      margin: 0 auto 36px;
      line-height: 1.75;
      font-weight: 500;
    }

    .hero-btns {
      display: flex;
      gap: 14px;
      justify-content: center;
      flex-wrap: wrap;
      position: relative;
      z-index: 1;
    }

    .btn-wa {
      display: inline-flex; align-items: center; gap: 8px;
      padding: 14px 32px; border-radius: 12px;
      background: linear-gradient(135deg, #25d366, #128c50);
      color: #fff; font-weight: 700; font-size: 17px;
      text-decoration: none;
      box-shadow: 0 6px 24px rgba(37,211,102,.4);
      font-family: 'Cairo', sans-serif;
      transition: transform .2s, box-shadow .2s;
    }
    .btn-wa:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(37,211,102,.5); }

    .btn-call {
      display: inline-flex; align-items: center; gap: 8px;
      padding: 14px 32px; border-radius: 12px;
      border: 2px solid rgba(240,200,74,.6);
      color: #f0c84a; font-weight: 700; font-size: 17px;
      text-decoration: none; background: transparent;
      font-family: 'Cairo', sans-serif;
      transition: background .2s, border-color .2s;
    }
    .btn-call:hover { background: rgba(240,200,74,.1); border-color: #f0c84a; }

    .btn-wa svg, .btn-call svg { width: 22px; height: 22px; fill: currentColor; flex-shrink: 0; }

    /* ====== SERVICES ====== */
    .services {
      padding: 56px 24px 48px;
      background: #f0f4fa;
      max-width: 980px;
      margin: 0 auto;
    }

    .section-label {
      font-size: 13px; font-weight: 700;
      color: #c9a227; letter-spacing: .1em;
      text-align: center; margin-bottom: 8px;
    }

    .section-title {
      font-size: clamp(22px, 4vw, 32px);
      font-weight: 800; color: #0d1b35;
      text-align: center; margin-bottom: 12px;
    }

    .gold-bar-sm {
      width: 48px; height: 3px;
      background: linear-gradient(90deg, #c9a227, #f0c84a);
      border-radius: 2px;
      margin: 0 auto 36px;
    }

    .cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 20px;
    }

    .card {
      background: #fff;
      border-radius: 16px;
      padding: 32px 28px;
      border: 1px solid #dde4f0;
      box-shadow: 0 2px 12px rgba(20,30,60,.07);
      text-align: center;
      position: relative;
      overflow: hidden;
      transition: transform .25s, box-shadow .25s;
    }
    .card:hover { transform: translateY(-4px); box-shadow: 0 8px 28px rgba(20,30,60,.13); }

    .card::before {
      content: '';
      position: absolute;
      top: 0; left: 50%; transform: translateX(-50%);
      width: 48px; height: 3px;
      background: linear-gradient(90deg, #c9a227, #f0c84a);
      border-radius: 0 0 4px 4px;
    }

    .card-icon {
      width: 64px; height: 64px;
      border-radius: 16px;
      background: linear-gradient(135deg, #0d1b35, #1e3560);
      display: flex; align-items: center; justify-content: center;
      margin: 0 auto 20px;
      color: #f0c84a;
    }
    .card-icon svg { width: 32px; height: 32px; stroke: #f0c84a; fill: none; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }

    .card h3 { font-size: 20px; font-weight: 800; color: #0d1b35; margin-bottom: 10px; }
    .card p  { font-size: 14.5px; color: #5a6a8a; line-height: 1.75; }

    /* ====== CTA STRIP ====== */
    .cta-strip {
      margin-top: 36px;
      padding: 28px 24px;
      border-radius: 14px;
      background: linear-gradient(135deg, #0d1b35, #1e3560);
      border: 1px solid rgba(201,162,39,.3);
      text-align: center;
    }

    .cta-strip p {
      font-size: 16px; font-weight: 600;
      color: rgba(230,220,195,.9);
      margin-bottom: 16px;
    }

    .cta-strip .btns { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }

    .cta-strip .btn-wa  { font-size: 15px; padding: 11px 24px; }
    .cta-strip .btn-call { font-size: 15px; padding: 11px 24px; }

    /* ====== FOOTER ====== */
    footer {
      background: #08111f;
      padding: 20px 24px;
      text-align: center;
      border-top: 1px solid rgba(201,162,39,.2);
    }

    footer p { font-size: 13px; color: rgba(201,162,39,.6); }

    footer a {
      color: #c9a227; text-decoration: none;
      font-weight: 600;
      border-bottom: 1px solid rgba(201,162,39,.4);
      padding-bottom: 1px;
      transition: color .2s;
    }
    footer a:hover { color: #f0c84a; }
  </style>
</head>
<body>

  <!-- Floating Icons -->
  <div class="floating-icons">
    <a class="float-btn wa" href="https://wa.me/966564819180" target="_blank" aria-label="واتساب">
      <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.117 1.528 5.847L0 24l6.337-1.518A11.94 11.94 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.808 9.808 0 01-5.002-1.371l-.36-.214-3.762.901.944-3.658-.234-.375A9.818 9.818 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>
    </a>
    <a class="float-btn tel" href="tel:+966564819180" aria-label="اتصال">
      <svg viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
    </a>
  </div>

  <!-- Header -->
  <header>
    <div class="brand">
      <div class="brand-icon">ب</div>
      <span class="brand-name">مكتب ابو بسام</span>
    </div>
  </header>

  <!-- Hero -->
  <section class="hero">
    <div class="gold-bar"></div>
    <h1>مكتب ابو بسام</h1>
    <p>نُعيد لك حريتك المالية — بحلول موثوقة وسريعة لتسوية ديونك وإنهاء مشاكلك المالية</p>
    <div class="hero-btns">
      <a class="btn-wa" href="https://wa.me/966564819180" target="_blank">
        <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.117 1.528 5.847L0 24l6.337-1.518A11.94 11.94 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.808 9.808 0 01-5.002-1.371l-.36-.214-3.762.901.944-3.658-.234-.375A9.818 9.818 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>
        تواصل عبر واتساب
      </a>
      <a class="btn-call" href="tel:+966564819180">
        <svg viewBox="0 0 24 24" fill="#f0c84a"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
        اتصل الآن
      </a>
    </div>
  </section>

  <!-- Services -->
  <section class="services">
    <p class="section-label">خدماتنا</p>
    <h2 class="section-title">نحل مشاكلك المالية</h2>
    <div class="gold-bar-sm"></div>

    <div class="cards">
      <div class="card">
        <div class="card-icon">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
        </div>
        <h3>تسديد قروض</h3>
        <p>نسدد قروضك البنكية وننهي التزاماتك المالية بكل سهولة واحترافية</p>
      </div>
      <div class="card">
        <div class="card-icon">
          <svg viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4M14 15h4"/></svg>
        </div>
        <h3>سداد متعثرات</h3>
        <p>نتولى معالجة الديون المتعثرة وإعادة ترتيبها بحلول مضمونة وفعّالة</p>
      </div>
      <div class="card">
        <div class="card-icon">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg>
        </div>
        <h3>سداد إيقاف الخدمات</h3>
        <p>نوقف إجراءات تجميد الخدمات الحكومية والبنكية فور التواصل معنا</p>
      </div>
    </div>

    <div class="cta-strip">
      <p>هل تحتاج إلى مساعدة؟ تواصل معنا الآن</p>
      <div class="btns">
        <a class="btn-wa" href="https://wa.me/966564819180" target="_blank">
          <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.117 1.528 5.847L0 24l6.337-1.518A11.94 11.94 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.808 9.808 0 01-5.002-1.371l-.36-.214-3.762.901.944-3.658-.234-.375A9.818 9.818 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>
          واتساب
        </a>
        <a class="btn-call" href="tel:+966564819180">
          <svg viewBox="0 0 24 24" fill="#f0c84a"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
          +966564819180
        </a>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <p>تصميم الإعلان: <a href="https://wa.me/01149049682" target="_blank">م. محمد علي</a></p>
  </footer>

  <?php wp_footer(); ?>
</body>
</html>
